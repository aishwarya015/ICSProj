package One;
public class DocReg {
	private String fname1;
	private String mailid1;
	private String pass1;
	private double number1;
	private String Category;
	private double fees;
	private String timings;
	private double Experience;
	private String addr1;
	private String City;
	private double Zipcode;
	private long docid1;
	
	public String getFname1() {
		return fname1;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public double getExperience() {
		return Experience;
	}
	public void setExperience(double experience) {
		Experience = experience;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public double getZipcode() {
		return Zipcode;
	}
	public void setZipcode(double zipcode) {
		Zipcode = zipcode;
	}
	public void setFname1(String fname1) {
		this.fname1 = fname1;
	}
	public String getMailid1() {
		return mailid1;
	}
	public void setMailid1(String mailid1) {
		this.mailid1 = mailid1;
	}
	public String getPass1() {
		return pass1;
	}
	public void setPass1(String pass1) {
		this.pass1 = pass1;
	}
	public double getNumber1() {
		return number1;
	}
	public void setNumber1(double number1) {
		this.number1 = number1;
	}
	public String getAddr1() {
		return addr1;
	}
	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}
	public long getDocid1() {
		return docid1;
	}
	public void setDocid1(long docid1) {
		this.docid1 = docid1;
	}

}